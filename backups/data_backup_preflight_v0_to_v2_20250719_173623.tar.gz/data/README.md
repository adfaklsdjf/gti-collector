
Features to add
- created and updated dates - update updated date whenever scraped.. if created date isn't set, initialize to app creation

- add another site


- more fields
  - days on market
  - cargurus dealer rating
  - cargurus "deal" rating
  - stock #

- per-site URLs



fields to collect on each site:
- price
- mileage
- year
- vin
- distance
- location

- trim_level
- car_title
- accidents
- previous_owners
- phone_number
- title


drivetrain
mpg
engine
fuel_type
transmission
